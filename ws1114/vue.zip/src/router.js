import Vue from "vue";
import Router from "vue-router";
import NoticeLIst from "./components/NoticeLIst.vue";
import DetailNotice from "./components/DetailNotice.vue";
import DetailQnA from "./components/DetailQnA.vue";
import QnAList from "./components/QnAList.vue";
import AddQnA from "./components/AddQnA.vue";
import AddNotice from "./components/AddNotice.vue";
import ChartCustomer from "./components/ChartCustomer.vue";
import UpdateNotice from "./components/UpdateNotice.vue";
import UpdateQna from "./components/UpdateQna.vue";
import ChartPieCustomer from "./components/ChartPieCustomer.vue";
import SearchNotice from "./components/SearchNotice.vue";
import SearchNoticeByTitle from "./components/SearchNoticeByTitle.vue";
Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/",
      name: "customers",
      alias: "/customer",
      component: NoticeLIst
    },
    {
      path: '/detailnotice/:num',
      name: 'detailnotice',
      component: DetailNotice,
      props: true,
    },
    {
      path: '/detailqna/:num',
      name: 'detailqna',
      component: DetailQnA,
      props: true,
    },
    {
      path: "/qnalist",
      name: "qnalist",
      component: QnAList
    },
    {
      path: "/addqna/:noticenum",
      name: "addqna",
      component: AddQnA,
      props: true
    },
    {
      path: "/add",
      name: "add",
      component: AddNotice
    } ,
    {
      path: "/chartcustomer",
      name: "chartcustomer",
      component: ChartCustomer
    } 
    ,
    {
      path: '/updatenotice/:num',
      name: 'updatenotice',
      component: UpdateNotice,
      props: true
    }
    ,
    {
      path: '/updateqna/:num',
      name: 'updateqna',
      component: UpdateQna,
      props: true
    }
    ,
    {
      path: '/chartpiecustomer',
      name: 'chartpiecustomer',
      component: ChartPieCustomer
    },
    {
      path: '/searchnotice',
      name: 'searchnotice',
      component: SearchNotice
    },
    {
      path: '/searchnoticebytitle',
      name: 'searchnoticebytitle',
      component: SearchNoticeByTitle
    }
  ]
});