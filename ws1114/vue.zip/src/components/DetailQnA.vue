<template>
  <div>
    <table class="list_table">
      <col width="10%" />
      <col width="70%" />
      <col width="20%" />
     
      <tr>
        <th>공지번호</th>
        <th>제목</th>
        <th>작성자</th>
      </tr>
      <tr @click="show_detail(cemp.id)">
        <td v-html="cemp.id"></td>
        <td v-html="cemp.name"></td>
        <td v-html="cemp.dept_id"></td>
      </tr>
      <tr>
        <td colspan="3">Q : {{cemp.salary}}</td>
      </tr>
      
      <tr v-if="cemp.salary != 5000" >
        <td colspan="3">답변 : {{cemp.salary}}</td>
      </tr>
      <tr v-else>
        <td colspan="3">답변하기 : <input type="text" v-model="cemp.salary"> <input type="button" value="등록" @click="addanswer" /></td>
      </tr>
    </table>

    
    
  </div>
</template>

<script>
import http from "../http-common";

export default {
  name: "detailcustomer",
  props: ["num"],
  data() {
    return {
      info: [],
      loading: true,
      errored: false,
      cid: "",
      cemp: {}
    };
  },
  filters: {
    salarydecimal(value) {
      var a = parseInt(value);
      return a.toFixed(2);
    }
  },
  methods: {
    show_detail: function(employeeid) {
      alert(employeeid + "수정하기");
      //아래를 수정했다.
      this.$router.push("/updatecustomer/" + employeeid);
    },
    show_init: function() {
      http
        .get("/findEmployeeById/" + this.num)
        .then(response => (this.cemp = response.data))
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    },
    addanswer: function() {
      http
        .get("/findEmployeeById/" + this.num)
        .then(response => (this.cemp = response.data))
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    }
  },
  mounted() {
    this.show_init();
  }
};
</script>

<style>
.searchform {
  max-width: 300px;
  margin: auto;
}
.search-result {
  margin-top: 20px;
  text-align: left;
}
</style>