<template>
  <div>
    

    <div v-if="!submitted">
      <form action method="post" id="_frmForm" name="frmForm" @submit.prevent="updateNotice">
        <table class="content_table">
          <colgroup>
            <col style="width:30%;" />
            <col style="width:70%;" />
          </colgroup>
          <tr>
          <th>제목</th>
          <td><input data-msg="제목" type="text" name="title" id="_title"  v-model="notice.title" style="width:80%"/></td>
          </tr>
          <tr>
          <th>내용</th>
          <td><input data-msg="내용" type="text" name="content"  id="_content" size="20" v-model="notice.content" style="width:80% ; height:100px;"/></td>
          </tr>
          
          <tr>
            <td colspan="2" style="height:50px; text-align:center;">
              <button type="submit" name="button" class="btn btn-success">공지수정하기</button>
            </td>
          </tr>
        </table>
      </form>
    </div>

    <div class="search_box" v-else>
      <h3>
        <span style="color:blue;">성공적으로 수정하였습니다!</span>
      </h3>
    </div>
  </div>
</template>

<script>
import http from "../http-common";

export default {
  name: "updatecustomer",
  props: ["num"],
  data() {
    return {
      info: null,
      loading: true,
      errored: false,
      deps: null,
      titls: null,
      notice: {
        noticenum: '',
        title: '',
        writer:'',
        content:''
      },
      submitted: false
    };
  },
  mounted() {
    http
      .get("/noticedetail/" + this.num)
      .then(response => {
        this.notice = response.data;
      })
      .catch(() => {
        this.errored = true;
      })
      .finally(() => (this.loading = false));
    
  },
  methods: {
    show_detail: function() {
      alert(this.id + "상세보기");
      //아래를 수정했다.
      this.$router.push("/detailcustomer/" + this.id);
    },
    updateNotice() {
      if (this.notice.title == "") {
        alert("제목을 입력하세요.");
        return;
      }
      if (this.notice.content == "") {
        alert("내용을 입력하세요.");
        return;
      }

      http
        .post("/updateNotice", {
          noticenum: this.notice.noticenum,
         title: this.notice.title,
          writer: this.notice.writer,
          content: this.notice.content
        })
        .then(response => {
          if (response.data.state == "succ") {
            alert("정보를 수정 하였습니다.");
          } else {
            alert("정보를 수정 하지 못했습니다.");
          }
        });
      this.submitted = true;
    }
  }
};
</script>

<style>
.submitform {
  max-width: 300px;
  margin: auto;
}
</style>
