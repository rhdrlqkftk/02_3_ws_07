<template>

<div>
<div v-if="!submitted">
<form action="" method="post" id="_frmForm" name="frmForm" @submit.prevent="addEmployee">
<table class="content_table">
<colgroup>
		<col style="width:30%;" />
		<col style="width:70%;" />							
</colgroup>	
<tr>
<th>제목</th>
<td><input data-msg="제목" type="text" name="title" id="_title"  v-model="ctitle" style="width:30%"/></td>
</tr>
<tr>
<th>내용</th>
<td><input data-msg="내용" type="text" name="content"  id="_content" size="20" v-model="ccontent" style="width:30% ; height:100px;"/></td>
</tr>

<tr>
<td colspan="2" style="height:50px; text-align:center;">
<button type="submit" name="button">공지등록</button></td>
</tr>
</table>
</form>
</div>

<div v-else>
      <h4>성공적으로 공지를 등록하였습니다!</h4>
      <button class="btn btn-success" v-on:click="newCustomer">새로 공지 등록하기</button>
    </div>
</div>

</template>

<script>
import http from "../http-common";

export default {
	name: "add-customer",
	data() {
		return {
			info: null,
			loading: true,
			errored: false,
			ctitle:'',
			ccontent:'',
			cwriter:'admin',
			submitted: false
		};
	},
	filters: {
		salarydecimal (value) {
			var a=parseInt(value);
			return a.toFixed(2);
		}
	}, 
	mounted () {
	
	},
	methods: {
	addEmployee() {
		if(this.ctitle==''){ alert('제목을 입력하세요.'); return ;}
		if(this.ccontent==''){ alert('내용을 입력하세요.'); return ;}
		
		http.post('/addNotice', {
			title:this.ctitle,
			content: this.ccontent,
			writer : this.cwriter
		} 
		).then(response => {
			alert(response.data.state);
				if (response.data.state=='succ') {
					alert("공지등록을 하였습니다.");
				}else{
					alert("공지등록을 하지 못했습니다.");
				}
		});
		this.submitted = true;
	},
	newCustomer() {
		this.submitted=false,
		this.ctitle='',
		this.ccontent=''
	}
  }
}
</script>

<style>
.submitform {
  max-width: 300px;
  margin: auto;
}
</style>
