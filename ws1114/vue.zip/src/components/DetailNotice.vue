<template>
  <div>
    <table class="list_table">
      <col width="10%" />
      <col width="70%" />
      <col width="20%" />
     
      <tr>
        <th>공지번호</th>
        <th>제목</th>
        <th>작성자</th>
      </tr>
      <tr @click="show_detail(cemp.noticenum)">
        <td v-html="cemp.noticenum"></td>
        <td v-html="cemp.title"></td>
        <td v-html="cemp.writer"></td>
      </tr>
      <tr>
        <td colspan="3">내용 : {{cemp.content}}</td>
      </tr>
    </table>
    <table class="list_table">
        <col width="10%" />
        <col width="20%" />
        <col width="60%" />
        <col width="10%" />
        <tr>
          <th>QnA번호</th>
          <th>작성자</th>
          <th>내용</th>
          <th>삭제</th>
        </tr>
        <tr v-for="qna in comment" class="nicecolor" :key="qna.qnanum">
          <td v-html="qna.qnanum" @click="update_qna(qna.qnanum)"></td>
          <td v-html="qna.writer"></td>
          <td v-html="qna.content"></td>
          <td class="button" @click="delete_qna(qna.qnanum)">
            <input type="button" class="blue" value="삭제" />
          </td>
        </tr>
        
        <tr>
          <td class="button" colspan="4" @click="addqna(cemp.noticenum)">
            <input type="button" class="blue" value="QnA추가"/>
          </td>
        </tr>

      </table>

    
  </div>
</template>

<script>
import http from "../http-common";

export default {
  name: "detailcustomer",
  props: ["num"],
  data() {
    return {
      info: [],
      loading: true,
      errored: false,
      cid: "",
      cemp: {},
      comment:{}
    };
  },
  filters: {
    salarydecimal(value) {
      var a = parseInt(value);
      return a.toFixed(2);
    }
  },
  methods: {
    show_detail: function(employeeid) {
      alert(employeeid + "수정하기");
      //아래를 수정했다.
      this.$router.push("/updatenotice/" + employeeid);
    },
    show_init: function() {
      http
        .get("/noticedetail/" + this.num)
        .then(response => (this.cemp = response.data))
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
      http
        .get("/findQna/" + this.num)
        .then(response => (this.comment = response.data))
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    },
    addqna: function(noticenum) {
      this.$router.push("/addqna/"+noticenum);
    },
    delete_qna: function(qnanum){
      http
       .delete("/deleteQna/"+qnanum)
       .finally(() => (this.loading = false,this.show_init()));
      
    },
    update_qna: function(qnanum){
      this.$router.push("/updateqna/"+qnanum);
    }
  },
  mounted() {
    this.show_init();
  }
};
</script>

<style>
.searchform {
  max-width: 300px;
  margin: auto;
}
.search-result {
  margin-top: 20px;
  text-align: left;
}
</style>