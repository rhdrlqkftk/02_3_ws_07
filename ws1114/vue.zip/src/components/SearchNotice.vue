<template>
  <div>
    <div>
      작성자 검색 : <input type="text" v-model="search" @keyup="searchname" v-cloak>
      <table class="list_table">
        <col width="10%" />
        <col width="70%" />
        <col width="20%" />
        <tr>
          <th>공지 번호</th>
          <th>제목</th>
          <th>작성자</th>
          <th>삭제</th>
        </tr>
        <tr v-for="notice in notices" class="nicecolor" :key="notice.noticenum">
          <td v-html="notice.noticenum" @click="show_detail(notice.noticenum)"></td>
          <td v-html="notice.title" @click="show_detail(notice.noticenum)"></td>
          <td v-html="notice.writer"></td>
          <td class="button" @click="delete_notice(notice.noticenum)">
            <input type="button" class="blue" value="삭제" />
          </td>
        </tr>
      </table>
      
    </div>
  </div>
</template>

<script>
import http from "../http-common";
export default {
  name: "customers-list",
  data() {
    return {
      search :"",
      upHere: false,
      notices: [],
      loading: true,
      errored: false
    };
  },
  methods: {
    searchname(e) {
      if (e.which == 13) {
        //enter
        http
          .get("/findAllNoticeByname/" + this.search)
          .then(response => (this.notices = response.data))
          .catch(() => {
            this.errored = true;
          })
          .finally(() => (this.loading = false));
      }
    },
    refreshList() {
      this.retrieveCustomers();
    },
    show_detail: function(noticenum) {
      alert(noticenum + "번 공지 상세보기");
      this.$router.push("/detailnotice/" + noticenum);
    },
    delete_notice(noticenum) {
      
      alert(noticenum + "번 공지를 삭제합니다.");
      http
        .delete("/deletemem/" + noticenum)
        .then(response => {
          alert("왜안돼");
          if (response.data.state == "succ") {
            alert("삭제를 하였습니다.");
            this.retrieveCustomers();
          } else {
            alert("삭제를 하지 못했습니다.");
          }
        })
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    }
  },
  filters: {
    salarydecimal(value) {
      var a = parseInt(value);
      return a.toFixed(2);
    }
  },
  mounted() {
    this.retrieveCustomers();
  }
};
</script>

<style>
</style>
