<template>
  <div>
    <div>
      <table class="list_table">
        <col width="10%" />
        <col width="70%" />
        <col width="20%" />
        <tr>
          <th>QnA 번호</th>
          <th>질문</th>
          <th>작성자</th>
          <th>삭제</th>
        </tr>
        <tr v-for="qna in info" class="nicecolor" :key="qna.qnanum">
          <td v-html="qna.qnanum" @click="show_detail(qna.qnanum)"></td>
          <td v-html="qna.title" @click="show_detail(qna.qnanum)"></td>
          <td v-html="qna.writer"></td>
          <td class="button" @click="delete_qna(qna.noticenum)">
            <input type="button" class="blue" value="삭제" />
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>

<script>
import http from "../http-common";
export default {
  name: "customers-list",
  data() {
    return {
      upHere: false,
      info: [],
      loading: true,
      errored: false
    };
  },
  methods: {
    retrieveCustomers() {
      http
        .get("/findAllQna")
        .then(response => (this.info = response.data))
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    },
    refreshList() {
      this.retrieveCustomers();
    },
    show_detail: function(qnanum) {
      alert(qnanum + "번 공지 상세보기");
      this.$router.push("/detailqna/" + qnanum);
    },
    delete_qna(qnanum) {
      
      alert(qnanum + "번 QnA를 삭제합니다.");
      http
        .post("/deletemem/" + qnanum)
        .then(response => {
          if (response.data.state == "succ") {
            alert("삭제를 하였습니다.");
            this.retrieveCustomers();
          } else {
            alert("삭제를 하지 못했습니다.");
          }
        })
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    }
  },
  filters: {
    salarydecimal(value) {
      var a = parseInt(value);
      return a.toFixed(2);
    }
  },
  mounted() {
    this.retrieveCustomers();
  }
};
</script>

<style>
</style>
