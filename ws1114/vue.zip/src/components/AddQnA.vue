<template>

<div>
<div v-if="!submitted">
<h3>{{cnoticenum}}번 공지사항 댓글</h3>

<form action="" method="post" id="_frmForm" name="frmForm" @submit.prevent="addEmployee">

<table class="content_table">
<colgroup>
		<col style="width:15%;" />
		<col style="width:85%;" />							
</colgroup>	


<tr>
<th>작성자</th>
<td><input data-msg="작성자" type="text" name="writer" id="_writer"  v-model="cwriter" style="width:30%"/></td>
</tr>
<tr>
<th>내용</th>
<td><input data-msg="내용" type="text" name="content"  id="_content" size="20" v-model="ccontent" style="width:30% ; height:100px;"/></td>
</tr>


<tr>
<td colspan="2" style="height:50px; text-align:center;">
<button type="submit" name="button">QnA 추가</button></td>
</tr>
</table>
</form>
</div>

<div v-else>
      <h4>성공적으로 QnA를 등록하였습니다!</h4>
      <button class="btn btn-success" v-on:click="newCustomer">새로 QnA 추가하기</button>
    </div>
</div>

</template>

<script>
import http from "../http-common";

export default {
  name: "add-customer",
  props:["noticenum"],
	data() {
		return {
			info: null,
			loading: true,
      errored: false,
      cnoticenum : this.noticenum,
			ccontent:'',
			cwriter:'',
			submitted: false
		};
	},
	filters: {
		salarydecimal (value) {
			var a=parseInt(value);
			return a.toFixed(2);
		}
	}, 
	mounted () {

	},
	methods: {
	addEmployee() {
		if(this.cwriter==''){ alert('작성자를 입력하세요.'); return ;}
		if(this.ccontent==''){ alert('내용을 입력하세요.'); return ;}
		
		http.post('/addQna', {
			noticenum : this.cnoticenum,
			content: this.ccontent,
			writer : this.cwriter
		} 
		).then(response => {
				if (response.data.state=='succ') {
					alert("QnA를 등록하였습니다.");
				}else{
					alert("QnA를 등록하지 못했습니다.");
				}
		});
		this.submitted = true;
	},
	newCustomer() {
		this.submitted=false,
		this.ctitle='',
		this.ccontent=''
	}
  }
}
</script>

<style>
.submitform {
  max-width: 300px;
  margin: auto;
}
</style>
