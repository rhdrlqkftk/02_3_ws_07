<template>
<div id="app">
<div class='headtitle'><h2>Safe Food</h2></div>
<div class='search_box'>
 <nav>
        <router-link class="btn btn-primary" to="/">공지사항</router-link> |
        <router-link class="btn btn-primary" to="/add">공지사항 등록</router-link> |
        <router-link class="btn btn-primary" to="/searchnotice">작성자로 검색</router-link> |
        <router-link class="btn btn-primary" to="/searchnoticebytitle">제목으로 검색</router-link> |
        <router-link class="btn btn-primary" to="/chartpiecustomer">알레르기 보기2</router-link>
 </nav>
</div>
        <router-view/>
</div>
</template>

<script>
export default {
  name: "app"
};
</script>

<style>

</style>
